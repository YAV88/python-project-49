from random import randint


SPECIFICATION =
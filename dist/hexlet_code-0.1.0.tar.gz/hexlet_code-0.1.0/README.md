### Hexlet tests and linter status:
[![Actions Status](https://github.com/YAV88/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/YAV88/python-project-49/actions)


### Asciinema rec
https://asciinema.org/a/H8MfLQiwrnrt4XwvdjeKHZS2v   # Rec game brain-even

https://asciinema.org/a/VtY20KQwA7gGXyCdzZ0U5492M   # Rec game brain-calc

https://asciinema.org/a/JriMDlLhS27nwOe0NV7wbDE7D   # Rec game brain-gcd

https://asciinema.org/a/6I2GOETN7AG4PcR57W15tdyvj   # Rec game brain-progression